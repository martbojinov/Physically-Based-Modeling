#include "ofApp.h"

// Helper Functions
float RandomFloat(float a, float b) {
	float random = ((float)rand()) / (float)RAND_MAX;
	float diff = b - a;
	float r = random * diff;
	return a + r;
}


//--------------------------------------------------------------
void ofApp::setup(){
	// GUI Setup
	gui.setup(); // most of the time you don't need a name

	// BOID GUI
	gui.add(boid_num.setup("Number of Boids Displayed", 100, 1, 100));
	gui.add(boid_scale.setup("Boid Scale", 5, 1, 20));

	// BOID Physics
	gui.add(boid_minspeed.setup("Boid Min Speed", 50, 0, 300));
	gui.add(boid_maxspeed.setup("Boid Max Speed", 100, 0, 300));
	gui.add(boid_turning.setup("Boid Turning Rate", 0.1, 0, 1));
	gui.add(turbulence_pos.setup("Positive Turbulence", { 0, 0, 0 }, { 0, 0, 0 }, { 20, 20, 20 }));
	gui.add(turbulence_neg.setup("Negative Turbulence", { 0, 0, 0 }, { -20, -20, -20 }, { 0, 0, 0 }));

	// rotation testing slider
	gui.add(change_rotation.setup("Manually Change Rotation", false));
	gui.add(rotation_slide.setup("Rotation Testing", { 0, 0, 0 }, { 0, 0, 0 }, { 360, 360, 360 }));

	// flap frequency
	gui.add(flap_freq_slider.setup("Flap Frequency", 5, 1, 20));
	

	// Mode GUI
	gui.add(targetting_mode.setup("Targetting Mode", false));
	gui.add(run_sim.setup("Run Simulation", false));
	gui.add(reset_button.setup("Reset Boids"));

	// Misc GUI
	gui.add(screenSize.setup("screen size", ofToString(ofGetWidth()) + "x" + ofToString(ofGetHeight())));

	// background
	// ofSetBackgroundColor(ofColor::black);

	// cam settings
	//cam.setDistance(10);
	//cam.setNearClip(.1);
	//ofEnableDepthTest();

	// enable or disable wireframe for models
	bWireFrame = false;

	// boid model 1
	if (!boidModel1.loadModel("bee1.obj")) {
		cout << "Can't load model 1" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded1 = true;
		boidModel1.setScaleNormalization(false);
	}

	// boid model 2
	if (!boidModel2.loadModel("bee2.obj")) {
		cout << "Can't load model 2" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded2 = true;
		boidModel2.setScaleNormalization(false);
	}

	// boid model 3
	if (!boidModel3.loadModel("bee3.obj")) {
		cout << "Can't load model 3 " << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded3 = true;
		boidModel3.setScaleNormalization(false);
	}

	// boid model 4
	if (!boidModel4.loadModel("bee4.obj")) {
		cout << "Can't load model 4" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded4 = true;
		boidModel4.setScaleNormalization(false);
	}

	// boid model 5
	if (!boidModel5.loadModel("bee5.obj")) {
		cout << "Can't load model 5" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded5 = true;
		boidModel5.setScaleNormalization(false);
	}

	// boid model 6
	if (!boidModel6.loadModel("bee6.obj")) {
		cout << "Can't load model 6" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded6 = true;
		boidModel6.setScaleNormalization(false);
	}

	// print models
	cout << "Mesh 1 vertices: " << boidModel1.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 2 vertices: " << boidModel2.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 3 vertices: " << boidModel3.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 4 vertices: " << boidModel4.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 5 vertices: " << boidModel5.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 6 vertices: " << boidModel6.getMesh(0).getNumVertices() << endl;

	// Set up lighting
	ofSetSmoothLighting(true);

	// setup one point light
	light1.enable();
	light1.setPosition(0, 20, 0);
	light1.setDiffuseColor(ofColor(255.f, 255.f, 255.f));
	light1.setSpecularColor(ofColor(255.f, 255.f, 255.f));
	light1.setAmbientColor(ofColor(150, 150, 150));
}

//--------------------------------------------------------------
void ofApp::update(){
	// update scale
	float s = boid_scale;

	int current_boid_num = min(int(f1.boid_list.size()), int(boid_num));
	for (int i = 0; i < current_boid_num; i++) {
		// update scale
		f1.boid_list[i].scale = glm::vec3(s, s, s);

		// update min max speeds
		f1.boid_list[i].maxspeed = boid_maxspeed;
		f1.boid_list[i].minspeed = boid_minspeed;

		// update rotation when not in simulation
		if (change_rotation) {
			glm::vec3 euler_rot = glm::vec3(glm::radians(rotation_slide->x), glm::radians(rotation_slide->y), glm::radians(rotation_slide->z));
			glm::quat q = glm::quat(euler_rot);
			f1.boid_list[i].rotations = ofQuaternion(q);
		}

		// update turning rate
		f1.boid_list[i].turning_rate = boid_turning;

		// update flap freq
		f1.boid_list[i].flap_freq = flap_freq_slider;

		// update turbulence
		glm::vec3 t_pos = turbulence_pos;
		glm::vec3 t_neg = turbulence_neg;
		if (glm::length(t_pos) > 0 || glm::length(t_neg) > 0) {	// there is turbulence in at least one direction
			float t_x = RandomFloat(turbulence_pos->x, turbulence_neg->x);
			float t_y = RandomFloat(turbulence_pos->y, turbulence_neg->y);
			float t_z = RandomFloat(turbulence_pos->z, turbulence_neg->z);
			f1.boid_list[i].applyForce(glm::vec3(t_x, t_y, 0));	// z = 0 because 2d for now
		}

		// run simulations
		if (run_sim) {
			f1.boid_list[i].integrate();	// run physics

			if (targetting_mode) {			// targetting mode enabled
				f1.boid_list[i].followTarget(target_circle_pos);
			}
			else {							// flock
				f1.boid_list[i].participate_in_flock(f1.boid_list);
			}
		}

		
	}

	if (reset_button) {
		f1.boid_list.clear();
	}
}

//--------------------------------------------------------------
void ofApp::draw(){

	// background
	ofBackgroundGradient(ofColor::white, ofColor::gray);

	// draw everything in 3D through camera
	cam.begin();

		// draw Grid
		ofPushMatrix();
		ofSetColor(ofColor::dimGray);
		ofRotateDeg(90);
		ofDrawGridPlane(15, 10);
		ofPopMatrix();

		/*// draw Model
		if (bBoidModelLoaded1) {
			if (bWireFrame) {
				ofSetColor(ofColor::blue);
				boidModel1.drawWireframe();
			}
			else {
				ofEnableLighting();
				beeMaterial.setDiffuseColor(ofColor::red);
				beeMaterial.begin();
				ofSetColor(ofColor::yellow);
				boidModel1.enableMaterials();
				boidModel1.enableColors();
				boidModel1.enableNormals();
				boidModel1.drawFaces();

				//ofDrawSphere(5.0);
				beeMaterial.end();
				ofDisableLighting();
			}
		}*/

		// draw targetting circle
		if (targetting_mode) {	// only draw in targetting mode
			ofFill();
			ofSetColor(ofColor::red);
			ofDrawSphere(target_circle_pos, 4);
		}

		// draw boids
		int current_boid_num = min(int(f1.boid_list.size()), int(boid_num));
		for (int i = 0; i < current_boid_num; i++) {
			f1.boid_list[i].draw();
		}

	cam.end();

	// draw GUI
	gui.draw();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	int current_boid_num = min(int(f1.boid_list.size()), int(boid_num));
	if (key == OF_KEY_UP) {
		for (int i = 0; i < current_boid_num; i++) {
			f1.boid_list[i].accelerate();
		}
	}
	else if (key == OF_KEY_DOWN) {
		for (int i = 0; i < current_boid_num; i++) {
			f1.boid_list[i].decelerate();
		}
	}
	else if (key == OF_KEY_CONTROL) {	// enable placing boids
		place_boids = true;
	}
	else if (key == 's') {
		// do nothing
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
	if (key == OF_KEY_CONTROL) {		// disable placing boids
		place_boids = false;
	}

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
	//
	// construct mouse ray
	//
	glm::vec3 mouseWorld	= cam.screenToWorld(glm::vec3(x, y, 0));
	glm::vec3 camPosition	= cam.getPosition();
	glm::vec3 mouseDir		= glm::normalize(mouseWorld - camPosition);

	// test rayPlaneIntersect
	float dist;
	bool bIntersect = glm::intersectRayPlane(camPosition, mouseDir, glm::vec3(0, 0, 0), glm::vec3(0, 1, 0), dist);

	//cout << "intersect: " << bIntersect << endl;
	if (bIntersect) {
		//cout << "distance: " << dist << endl;

		// compute intersection point
		// r(t) = o + dt
		glm::vec3 p = camPosition + mouseDir * dist;

		//cout << "intersection point: " << p << endl;

		if (targetting_mode) {		// targetting mode on, turn boids towards point
			target_circle_pos = p;		// update targetting circle location
		}
		else if (place_boids) {		// placing boids is enabled
			// get current scale
			float s = boid_scale;

			// create new boid with current parameters
			Boid* bd = new Boid;
			bd->position	= p;
			bd->scale		= glm::vec3(s, s, s);
			bd->rotation_xy	= 0;

			bd->flap_freq		= flap_freq_slider;
			bd->total_frames	= 0;
			bd->start_frame		= 1;
			bd->flap_direction  = true;

			bd->maxspeed		= boid_maxspeed;
			bd->minspeed		= boid_minspeed;
			bd->turning_rate	= boid_turning;

			bd->model1	= &boidModel1;
			bd->model2	= &boidModel2;
			bd->model3	= &boidModel3;
			bd->model4	= &boidModel4;
			bd->model5	= &boidModel5;
			bd->model6	= &boidModel6;

			bd->material = &beeMaterial;
			f1.addBoid(*bd);

			// accelerate the boid that was just added
			int i = f1.boid_list.size() - 1;
			f1.boid_list[i].accelerate();
			f1.boid_list[i].integrate();
		}


	}



	

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
