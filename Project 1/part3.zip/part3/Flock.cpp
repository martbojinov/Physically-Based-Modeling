#pragma once
#include "Flock.h"

void Flock::addBoid(Boid bd) {
	boid_list.push_back(bd);
}