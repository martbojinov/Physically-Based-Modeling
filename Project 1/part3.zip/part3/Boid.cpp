#pragma once
#include "Boid.h"

void Boid::draw() {

	glm::mat4 T = getTranslateMatrix();
	glm::mat4 S = getScaleMatrix();
	glm::mat4 R = getRotationMatrix();
	glm::mat4 M = T * R * S;

	ofPushMatrix();
	ofMultMatrix(M);

	/*// 2D triangle
	ofNoFill();
	ofSetColor(ofColor::black);
	ofDrawTriangle(verts[0], verts[1], verts[2]);*/

	// update heading
	glm::vec4 head = glm::vec4(verts[1], 1);
	head = M * head;
	heading = glm::vec3(head.x, head.y, head.z);
	heading = heading - position;
	heading = glm::normalize(heading);

	/*
	// 3D Cone
	ofFill();
	ofSetColor(ofColor::lightPink);
	ofDrawCone(4.0, -9.0);
	*/

	ofPopMatrix();

	// get coord for model
	glm::vec3 euler_coords = rotations.getEuler();

	switch (start_frame) {	// 1-6 random num
	case 1:
		// Load Model 1
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model1->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model1->setRotation(0, euler_coords.y, 0, -1, 0);
		model1->setRotation(1, 180, 0, 0, 1);
		model1->setRotation(2, euler_coords.z, 0, 0, 1);
		model1->setRotation(3, 90, 1, 0, 0);
		model1->setRotation(4, euler_coords.x, 1, 0, 0);
		model1->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model1->enableMaterials();
		model1->enableColors();
		model1->enableNormals();
		model1->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 2:
		// Load Model 2
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model2->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model2->setRotation(0, euler_coords.y, 0, -1, 0);
		model2->setRotation(1, 180, 0, 0, 1);
		model2->setRotation(2, euler_coords.z, 0, 0, 1);
		model2->setRotation(3, 90, 1, 0, 0);
		model2->setRotation(4, euler_coords.x, 1, 0, 0);
		model2->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model2->enableMaterials();
		model2->enableColors();
		model2->enableNormals();
		model2->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 3:
		// Load Model 3
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model3->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model3->setRotation(0, euler_coords.y, 0, -1, 0);
		model3->setRotation(1, 180, 0, 0, 1);
		model3->setRotation(2, euler_coords.z, 0, 0, 1);
		model3->setRotation(3, 90, 1, 0, 0);
		model3->setRotation(4, euler_coords.x, 1, 0, 0);
		model3->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model3->enableMaterials();
		model3->enableColors();
		model3->enableNormals();
		model3->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 4:
		// Load Model 4
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model4->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model4->setRotation(0, euler_coords.y, 0, -1, 0);
		model4->setRotation(1, 180, 0, 0, 1);
		model4->setRotation(2, euler_coords.z, 0, 0, 1);
		model4->setRotation(3, 90, 1, 0, 0);
		model4->setRotation(4, euler_coords.x, 1, 0, 0);
		model4->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model4->enableMaterials();
		model4->enableColors();
		model4->enableNormals();
		model4->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 5:
		// Load Model 5
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model5->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model5->setRotation(0, euler_coords.y, 0, -1, 0);
		model5->setRotation(1, 180, 0, 0, 1);
		model5->setRotation(2, euler_coords.z, 0, 0, 1);
		model5->setRotation(3, 90, 1, 0, 0);
		model5->setRotation(4, euler_coords.x, 1, 0, 0);
		model5->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model5->enableMaterials();
		model5->enableColors();
		model5->enableNormals();
		model5->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 6:
		// Load Model 6
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model6->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model6->setRotation(0, euler_coords.y, 0, -1, 0);
		model6->setRotation(1, 180, 0, 0, 1);
		model6->setRotation(2, euler_coords.z, 0, 0, 1);
		model6->setRotation(3, 90, 1, 0, 0);
		model6->setRotation(4, euler_coords.x, 1, 0, 0);
		model6->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model6->enableMaterials();
		model6->enableColors();
		model6->enableNormals();
		model6->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	}

	// update model every flap_freq frames
	if (total_frames % (flap_freq) == 0) {
		if (start_frame <= 1) {
			flap_direction = true;
		}
		else if(start_frame >= 6) {
			flap_direction = false;
		}

		if (flap_direction) {	// increment animations up
			start_frame += 1;
		}
		else {					// decrement animations down
			start_frame -= 1;
		}

	}

	// increament frames
	total_frames += 1;

}

void Boid::integrate() {
	// get time
	float fr = ofGetFrameRate();
	if (fr == 0) {
		fr = 1.0;
	}
	float t = 1 / fr;

	// update acceleration
	acceleration += force;

	// new position
	position = position + (velocity * t);

	// new velocity
	velocity = velocity + (acceleration * t);

	// damp velocity
	// velocity = velocity * (1.0);	// do not damp
	velocity = velocity * (0.99);	// damp

	// check for max, min speed errors
	if (maxspeed < minspeed) {
		maxspeed = minspeed;
	}

	// limit velocity to max and min (min takes priority over max)
	float speed = glm::length(velocity);
	if (speed > maxspeed && speed != 0) {
		velocity = glm::normalize(velocity) * maxspeed;
	}
	if (speed < minspeed && speed != 0) {
		velocity = glm::normalize(velocity) * minspeed;
	}

	// reset acceleration
	acceleration = acceleration * 0.5;
	force = glm::vec3(0, 0, 0);

	// Wraparound checking
	//if (position.x < 0) position.x = ofGetWidth();
	//if (position.y < 0) position.y = ofGetHeight();
	//if (position.x > ofGetWidth()) position.x = 0;
	//if (position.y > ofGetHeight()) position.y = 0;

	// Debug Prints
	//cout << "P" << position << endl;
	//cout << "A" << acceleration << endl;
	//cout << "V" << velocity << endl;

	return;
}

void Boid::followTarget(glm::vec3 target) {

	// get vectors
	glm::vec3 target_vec = position - target;

	// normalize vectors
	heading = glm::normalize(heading);
	target_vec = glm::normalize(target_vec);

	ofFill();
	ofSetColor(ofColor::red);
	ofDrawSphere(heading, 2);

	ofFill();
	ofSetColor(ofColor::blue);
	ofDrawSphere(target_vec, 2);


	// get angle between target and heading
	float angle1 = glm::orientedAngle(heading, target_vec, glm::vec3(1, 0, 0));
	float angle2 = glm::orientedAngle(heading, target_vec, glm::vec3(0, 1, 0));
	float angle3 = glm::orientedAngle(heading, target_vec, glm::vec3(0, 0, 1));

	glm::vec3 eul_rot = glm::vec3(angle1, 0, 0);
	glm::vec3 eul_rot_deg = glm::vec3(glm::degrees(eul_rot.x), glm::degrees(eul_rot.y), glm::degrees(eul_rot.z));

	cout << "degrees to turn: " << eul_rot_deg << endl;

	glm::vec3 cur_eul = rotations.getEuler();
	glm::vec3 cur_eul_deg = glm::vec3(glm::degrees(cur_eul.x), glm::degrees(cur_eul.y), glm::degrees(cur_eul.z));

	cout << "curr degrees: " << cur_eul_deg << endl;

	glm::vec3 new_euler = cur_eul + (eul_rot * turning_rate);
	glm::vec3 new_euler_deg = glm::vec3(glm::degrees(new_euler.x), glm::degrees(new_euler.y), glm::degrees(new_euler.z));

	cout << "new degrees: " << new_euler_deg << endl;

	glm::vec4 temp_vec4 = rotations.asVec4();
	glm::quat q = glm::quat(temp_vec4.w, temp_vec4.x, temp_vec4.y, temp_vec4.z);

	float d = glm::radians(90.0f);
	q = glm::rotate(q, -angle1 * turning_rate * 0.05f, glm::vec3(1, 0, 0));
	q = glm::normalize(q);
	//q = glm::rotate(q, angle2 * turning_rate, glm::vec3(0, 1, 0));
	q = glm::rotate(q, -angle3 * turning_rate * 0.05f, glm::vec3(0, 0, 1));
	q = glm::normalize(q);

	rotations = ofQuaternion(q);


	// rotate and accelerate
	//rotation_xy -= angle * turning_rate;
	accelerate();

	return;
}

void Boid::participate_in_flock(vector<Boid> boid_list) {
	// heading vector in front of boid
	glm::vec3 heading_vec = glm::vec3(-sin(glm::radians(rotation_xy)), cos(glm::radians(rotation_xy)), 0);
	heading_vec = glm::normalize(heading_vec);

	// get seperation, cohesion, and alignment forces
	glm::vec3 sep = seperation(boid_list);
	glm::vec3 coh = cohesion(boid_list);
	glm::vec3 ali = alignment(boid_list);

	/*// weight forces (check for non-zero to prevent bugs)
	if (glm::length(sep) != 0) {
		sep = glm::normalize(sep);
		float sep_angle = glm::orientedAngle(heading_vec, sep, glm::vec3(0.0f, 0.0f, 1.0f));
		rotation_xy += sep_angle * 0.9 * turning_rate;
	}
	if (glm::length(coh) != 0) {
		glm::vec3 c_vec = coh - position;	// coh returns a centroid position
		coh = glm::normalize(c_vec);		// normalize vector to that postion
		float coh_angle = glm::orientedAngle(heading_vec, coh, glm::vec3(0.0f, 0.0f, 1.0f));
		rotation_xy += coh_angle * 0.8 * turning_rate;
	}
	if (glm::length(ali) != 0) {
		ali = glm::normalize(ali);
		float ali_angle = glm::orientedAngle(heading_vec, ali, glm::vec3(0.0f, 0.0f, 1.0f));
		rotation_xy += ali_angle * turning_rate;
	}*/

	// apply forces to boid
	//applyForce(sep);
	//applyForce(coh);
	//applyForce(ali);

	accelerate();

	return;
}

glm::vec3 Boid::seperation(vector<Boid> boid_list) {
	glm::vec3 steer = glm::vec3(0, 0, 0);

	// loop through all boids
	for (int i = 0; i < boid_list.size(); i++) {
		Boid current_boid = boid_list[i];

		// ignore self in list
		if (this->position == current_boid.position) {
			continue;
		}

		// get distances
		float desired_seperation = 50.0f;
		float distance = glm::distance(this->position, current_boid.position);

		// apply seperation rule
		if (distance > 0 && distance < desired_seperation) {
			glm::vec3 d_vec = this->position - current_boid.position;
			d_vec = glm::normalize(d_vec);
			d_vec = d_vec / distance;	// weight by closeness
			steer += d_vec;
		}
	}

	return steer;
}

glm::vec3 Boid::cohesion(vector<Boid> boid_list) {
	glm::vec3 steer = glm::vec3(0, 0, 0);
	glm::vec3 neighborhood_centroid = glm::vec3(0, 0, 0);
	int count = 0;

	// loop through all boids
	for (int i = 0; i < boid_list.size(); i++) {
		Boid current_boid = boid_list[i];

		// ignore self in list
		if (this->position == current_boid.position) {
			continue;
		}

		// get distances
		float neighborhood = 300.0f;
		float distance = glm::distance(this->position, current_boid.position);

		// get neighborhood centroid posiition
		if (distance > 0 && distance < neighborhood) {
			neighborhood_centroid += current_boid.position;
			count += 1;
		}
	}

	// apply cohesion rule
	if (count > 0) {		// avoid divide by zero error
		neighborhood_centroid = neighborhood_centroid / count;	// get avg position
		steer = neighborhood_centroid;
	}

	return steer;
}

glm::vec3 Boid::alignment(vector<Boid> boid_list) {
	glm::vec3 steer = glm::vec3(0, 0, 0);
	glm::vec3 neighborhood_heading = glm::vec3(0, 0, 0);
	int count = 0;

	// loop through all boids
	for (int i = 0; i < boid_list.size(); i++) {
		Boid current_boid = boid_list[i];

		// ignore self in list
		if (this->position == current_boid.position) {
			continue;
		}

		// get distances
		float neighborhood = 100.0f;
		float distance = glm::distance(this->position, current_boid.position);

		// get heading
		if (distance > 0 && distance < neighborhood) {
			neighborhood_heading += current_boid.velocity;
			count += 1;
		}
	}

	// apply alignment rule
	if (count > 0) {		// avoid divide by zero error
		neighborhood_heading = neighborhood_heading / count;		// get avg heading
		steer += neighborhood_heading;
	}

	return steer;
}

void Boid::accelerate() {
	force += heading * 150;
	return;
}

void Boid::decelerate() {
	force -= heading * 150;
	return;
}

void Boid::applyForce(glm::vec3 push) {
	force += push;
	return;
}