#pragma once
#include "ofMain.h"
#include "ofxAssimpModelLoader.h"

class Boid {
public:
	Boid() {
		verts.push_back(glm::vec3(5, -5, 0));
		verts.push_back(glm::vec3(0, 8, 0));
		verts.push_back(glm::vec3(-5, -5, 0));
	}

	glm::mat4 getTranslateMatrix() {
		return (glm::translate(glm::mat4(1.0), glm::vec3(position.x, position.y, position.z)));
	}

	glm::mat4 getScaleMatrix() {
		return (glm::scale(glm::mat4(1.0), glm::vec3(scale.x, scale.y, scale.z)));
	}

	/*
	// old 2d version of function
	glm::mat4 getRotationMatrix() {
		return (glm::rotate(glm::mat4(1.0), glm::radians(rotation_xy), glm::vec3(0, 0, 1)));
	}
	*/

	glm::mat4 getRotationMatrix() {
		glm::vec4 temp_vec4			= rotations.asVec4();
		glm::quat temp_rotations	= glm::quat(temp_vec4.w, temp_vec4.x, temp_vec4.y, temp_vec4.z);
		glm::mat4 RotationMatrix	= glm::toMat4(temp_rotations);

		return RotationMatrix;
	}

	
	

	// key functions
	void draw();			// draw boid
	void integrate();		// update physics

	// targetting mode
	void followTarget(glm::vec3 target);	

	// flocking rules
	void participate_in_flock(vector<Boid> boid_list);
	glm::vec3 seperation(vector<Boid> boid_list);
	glm::vec3 cohesion(vector<Boid> boid_list);
	glm::vec3 alignment(vector<Boid> boid_list);

	// arrow key controls
	void accelerate();
	void decelerate();

	// apply force to be calculated in physics
	void applyForce(glm::vec3 push);		

	vector<glm::vec3> verts;
	glm::vec3 position;
	glm::vec3 heading;
	glm::vec3 velocity;
	glm::vec3 acceleration;
	glm::vec3 force;
	glm::vec3 scale;

	ofxAssimpModelLoader *model1;
	ofxAssimpModelLoader *model2;
	ofxAssimpModelLoader *model3;
	ofxAssimpModelLoader *model4;
	ofxAssimpModelLoader *model5;
	ofxAssimpModelLoader *model6;

	ofMaterial *material;

	int		start_frame;
	int		total_frames;
	int		flap_freq;
	bool	flap_direction;

	ofQuaternion rotations;

	float minspeed;
	float maxspeed;
	float rotation_xy;
	float turning_rate;
};