#pragma once
#include "Robot.h"

void Robot::draw() {
	glm::mat4 T = getTranslateMatrix();
	glm::mat4 S = getScaleMatrix();
	glm::mat4 R = getRotationMatrix();
	glm::mat4 M = T * R * S;

	ofPushMatrix();
	ofMultMatrix(M);

	// update heading
	glm::vec4 head = glm::vec4(verts[1], 1);
	head = M * head;
	heading = glm::vec3(head.x, head.y, head.z);

	/*
	// 2D triangle
	ofNoFill();
	ofSetColor(ofColor::black);
	ofDrawTriangle(verts[0], verts[1], verts[2]);
	
	// 3D Cone
	ofFill();
	ofSetColor(ofColor::lightPink);
	ofDrawCone(4.0, -9.0);
	*/

	// Stop translation matrix
	ofPopMatrix();

	/*
	// debug spheres
	ofFill();
	ofSetColor(ofColor::red);
	ofDrawSphere(heading, 3);

	ofFill();
	ofSetColor(ofColor::green);
	ofDrawSphere(position, 3);

	ofFill();
	ofSetColor(ofColor::blue);
	ofDrawSphere(target, 3);

	ofNoFill();
	ofSetColor(ofColor::orange);
	ofDrawSphere(target2, 2.5);
	*/

	// get euler coords
	glm::vec3 euler_coords = rotations.getEuler();

	// draw model
	ofEnableLighting();
	//material.setDiffuseColor(ofColor::red);
	//material.begin();
	model->setRotation(0, euler_coords.y, 0, -1, 0);
	model->setRotation(1, 180, 0, 0, 1);
	model->setPosition(position.x, position.y, position.z);
	ofSetColor(ofColor::yellow);
	model->enableMaterials();
	model->enableColors();
	model->enableNormals();
	model->drawFaces();

	//ofDrawSphere(5.0);
	//material.end();
	ofDisableLighting();
}

void Robot::integrate() {
	// get time
	float fr = ofGetFrameRate();
	if (fr == 0) {
		fr = 1.0;
	}
	float t = 1 / fr;

	// update acceleration
	acceleration += force;

	// new position
	position = position + (velocity * t);

	// new velocity
	velocity = velocity + (acceleration * t);

	// damp velocity
	// velocity = velocity * (1.0);	// do not damp
	velocity = velocity * (0.98);	// damp

	// reset acceleration
	acceleration = acceleration * 0.5;
	force = glm::vec3(0, 0, 0);

	// Wraparound checking
	//if (position.x < 0) position.x = ofGetWidth();
	//if (position.y < 0) position.y = ofGetHeight();
	//if (position.x > ofGetWidth()) position.x = 0;
	//if (position.y > ofGetHeight()) position.y = 0;

	// Debug Prints
	//cout << "P" << position << endl;
	//cout << "A" << acceleration << endl;
	//cout << "V" << velocity << endl;

	return;
}

// wasd controls
void Robot::up() {
	glm::vec3 up = glm::vec3(0, 1, 0);
	force += up * thrust;
	return;
}

void Robot::down() {
	glm::vec3 up = glm::vec3(0, 1, 0);
	force -= up * thrust;
	return;
}

void Robot::left() {
	// get euler coords of robot
	glm::vec3 e = rotations.getEuler();

	// rotate left 10 degrees across y-axis
	ofQuaternion q3 = ofQuaternion(e.x, glm::vec3(1, 0, 0), e.y + 10, glm::vec3(0, 1, 0), e.z, glm::vec3(0, 0, 1));
	glm::vec3 e3 = q3.getEuler();

	// update
	rotations = q3;


	return;
}

void Robot::right() {
	// get euler coords of robot
	glm::vec3 e = rotations.getEuler();

	// rotate right 10 degrees across y-axis
	ofQuaternion q3 = ofQuaternion(e.x, glm::vec3(1, 0, 0), e.y-10, glm::vec3(0, 1, 0), e.z, glm::vec3(0, 0, 1));
	glm::vec3 e3 = q3.getEuler();

	// update
	rotations = q3;

	return;
}

void Robot::accelerate() {
	// get heading vector
	glm::vec3 h = heading - position;
	h = glm::normalize(h);

	force += h * thrust;
	return;
}

void Robot::decelerate() {
	// get heading vector
	glm::vec3 h = heading - position;
	h = glm::normalize(h);

	force -= h * thrust;
	return;
}

void Robot::applyForce(glm::vec3 push) {
	force += push;
	return;
}