#pragma once

#include "ofMain.h"
#include "ofxGui.h"
#include "Boid.h"
#include "Flock.h"
#include "Robot.h"
#include "box.h"
#include "vector3.h"
#include "ofxAssimpModelLoader.h"
#include <glm/gtx/intersect.hpp>

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);

		// cam
		ofEasyCam cam;
		
		// lighting
		ofLight light1;
		ofMaterial beeMaterial;

		// boid models
		ofxAssimpModelLoader boidModel1;
		ofxAssimpModelLoader boidModel2;
		ofxAssimpModelLoader boidModel3;
		ofxAssimpModelLoader boidModel4;
		ofxAssimpModelLoader boidModel5;
		ofxAssimpModelLoader boidModel6;

		bool bBoidModelLoaded1 = false;
		bool bBoidModelLoaded2 = false;
		bool bBoidModelLoaded3 = false;
		bool bBoidModelLoaded4 = false;
		bool bBoidModelLoaded5 = false;
		bool bBoidModelLoaded6 = false;

		// robot model
		ofxAssimpModelLoader roboModel;
		bool roboModelLoaded = false;

		// wireframe bool
		bool bWireFrame = true;
		
		// Targetting Circle
		glm::vec3 target_circle_pos = glm::vec3(500, 500, 0);

		// BOIDS class
		Flock f1;
		bool place_boids = false;

		// robot class
		Robot r1;

		// box
		Box b1;

		// --- GUI Variables ---

		// boid sliders
		ofxIntSlider	boid_num;
		ofxFloatSlider	boid_scale;
		ofxIntSlider	boid_minspeed;
		ofxIntSlider	boid_maxspeed;
		ofxFloatSlider	boid_turning;

		// boid turbulance
		ofxVec3Slider	turbulence_pos;
		ofxVec3Slider	turbulence_neg;

		// boid animation
		ofxIntSlider	flap_freq_slider;

		// boid orientation
		ofxToggle		change_rotation;
		ofxVec3Slider	rotation_slide;

		// robot thrust
		ofxIntSlider	robot_thrust;

		// toggles
		ofxToggle		predator_mode;
		ofxToggle		follower_mode;

		// sim buttons
		ofxToggle		targetting_mode;
		ofxToggle		run_sim;
		ofxButton		reset_button;

		// screen size info
		ofxLabel		screenSize;

		// GUI
		ofxPanel gui;
		ofxPanel gui2;
};
