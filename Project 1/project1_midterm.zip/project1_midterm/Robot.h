#pragma once
#include "ofMain.h"
#include "ofxAssimpModelLoader.h"

class Robot {
public:
	Robot() {
		verts.push_back(glm::vec3(5, -5, 0));
		verts.push_back(glm::vec3(0, 8, 0));
		verts.push_back(glm::vec3(-5, -5, 0));
	}

	glm::mat4 getTranslateMatrix() {
		return (glm::translate(glm::mat4(1.0), glm::vec3(position.x, position.y, position.z)));
	}

	glm::mat4 getScaleMatrix() {
		return (glm::scale(glm::mat4(1.0), glm::vec3(scale.x, scale.y, scale.z)));
	}

	/*
	// old 2d version of function
	glm::mat4 getRotationMatrix() {
		return (glm::rotate(glm::mat4(1.0), glm::radians(rotation_xy), glm::vec3(0, 0, 1)));
	}
	*/

	glm::mat4 getRotationMatrix() {
		glm::vec4 temp_vec4			= rotations.asVec4();
		glm::quat temp_rotations	= glm::quat(temp_vec4.w, temp_vec4.x, temp_vec4.y, temp_vec4.z);
		glm::mat4 RotationMatrix	= glm::toMat4(temp_rotations);

		return RotationMatrix;
	}

	// key functions
	void draw();			// draw boid
	void integrate();		// update physics

	// wasd controls
	void up();
	void down();
	void left();
	void right();

	// arrow key controls
	void accelerate();
	void decelerate();

	// apply force to be calculated in physics
	void applyForce(glm::vec3 push);		

	vector<glm::vec3> verts;
	glm::vec3 position;
	glm::vec3 heading;
	glm::vec3 target;
	glm::vec3 target2;
	glm::vec3 velocity;
	glm::vec3 acceleration;
	glm::vec3 force;
	glm::vec3 scale;

	int thrust = 150;

	ofxAssimpModelLoader *model;

	ofMaterial *material;

	ofQuaternion rotations = ofQuaternion(-0.707107, -0, -0, 0.707107);	// default rotation
	
	
};