#pragma once
#include "Boid.h"

void Boid::draw() {

	glm::mat4 T = getTranslateMatrix();
	glm::mat4 S = getScaleMatrix();
	glm::mat4 R = getRotationMatrix();
	glm::mat4 M = T * R * S;

	ofPushMatrix();
	ofMultMatrix(M);

	// update heading
	glm::vec4 head = glm::vec4(verts[1], 1);
	head = M * head;
	heading = glm::vec3(head.x, head.y, head.z);

	/*
	// 2D triangle
	ofNoFill();
	ofSetColor(ofColor::black);
	ofDrawTriangle(verts[0], verts[1], verts[2]);
	
	// 3D Cone
	ofFill();
	ofSetColor(ofColor::lightPink);
	ofDrawCone(4.0, -9.0);
	*/

	// Stop translation matrix
	ofPopMatrix();

	/*
	// debug spheres
	ofFill();
	ofSetColor(ofColor::blue);
	ofDrawSphere(target, 3);

	ofFill();
	ofSetColor(ofColor::red);
	ofDrawSphere(heading, 3);

	ofFill();
	ofSetColor(ofColor::green);
	ofDrawSphere(position, 3);
	*/

	// get coord for model
	glm::vec3 euler_coords = rotations.getEuler();

	
	switch (start_frame) {	// 1-6 random num
	case 1:
		// Load Model 1
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model1->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model1->setRotation(0, euler_coords.y, 0, -1, 0);
		model1->setRotation(1, 180, 0, 0, 1);
		model1->setRotation(2, euler_coords.z, 0, 0, 1);
		model1->setRotation(3, 90, 1, 0, 0);
		model1->setRotation(4, euler_coords.x, 1, 0, 0);
		model1->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model1->enableMaterials();
		model1->enableColors();
		model1->enableNormals();
		model1->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 2:
		// Load Model 2
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model2->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model2->setRotation(0, euler_coords.y, 0, -1, 0);
		model2->setRotation(1, 180, 0, 0, 1);
		model2->setRotation(2, euler_coords.z, 0, 0, 1);
		model2->setRotation(3, 90, 1, 0, 0);
		model2->setRotation(4, euler_coords.x, 1, 0, 0);
		model2->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model2->enableMaterials();
		model2->enableColors();
		model2->enableNormals();
		model2->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 3:
		// Load Model 3
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model3->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model3->setRotation(0, euler_coords.y, 0, -1, 0);
		model3->setRotation(1, 180, 0, 0, 1);
		model3->setRotation(2, euler_coords.z, 0, 0, 1);
		model3->setRotation(3, 90, 1, 0, 0);
		model3->setRotation(4, euler_coords.x, 1, 0, 0);
		model3->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model3->enableMaterials();
		model3->enableColors();
		model3->enableNormals();
		model3->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 4:
		// Load Model 4
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model4->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model4->setRotation(0, euler_coords.y, 0, -1, 0);
		model4->setRotation(1, 180, 0, 0, 1);
		model4->setRotation(2, euler_coords.z, 0, 0, 1);
		model4->setRotation(3, 90, 1, 0, 0);
		model4->setRotation(4, euler_coords.x, 1, 0, 0);
		model4->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model4->enableMaterials();
		model4->enableColors();
		model4->enableNormals();
		model4->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 5:
		// Load Model 5
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model5->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model5->setRotation(0, euler_coords.y, 0, -1, 0);
		model5->setRotation(1, 180, 0, 0, 1);
		model5->setRotation(2, euler_coords.z, 0, 0, 1);
		model5->setRotation(3, 90, 1, 0, 0);
		model5->setRotation(4, euler_coords.x, 1, 0, 0);
		model5->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model5->enableMaterials();
		model5->enableColors();
		model5->enableNormals();
		model5->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;

	case 6:
		// Load Model 6
		ofEnableLighting();
		material->setDiffuseColor(ofColor::red);
		material->begin();
		model6->setScale(scale.x / 25, scale.y / 25, scale.z / 25);
		model6->setRotation(0, euler_coords.y, 0, -1, 0);
		model6->setRotation(1, 180, 0, 0, 1);
		model6->setRotation(2, euler_coords.z, 0, 0, 1);
		model6->setRotation(3, 90, 1, 0, 0);
		model6->setRotation(4, euler_coords.x, 1, 0, 0);
		model6->setPosition(position.x, position.y, position.z);

		ofSetColor(ofColor::grey);
		model6->enableMaterials();
		model6->enableColors();
		model6->enableNormals();
		model6->drawFaces();

		//ofDrawSphere(5.0);
		material->end();
		ofDisableLighting();
		break;
	}

	// update model every flap_freq frames
	if (total_frames % (flap_freq) == 0) {
		if (start_frame <= 1) {
			flap_direction = true;
		}
		else if(start_frame >= 6) {
			flap_direction = false;
		}

		if (flap_direction) {	// increment animations up
			start_frame += 1;
		}
		else {					// decrement animations down
			start_frame -= 1;
		}

	}

	// increament frames
	total_frames += 1;

}

void Boid::integrate() {
	// get time
	float fr = ofGetFrameRate();
	if (fr == 0) {
		fr = 1.0;
	}
	float t = 1 / fr;

	// update acceleration
	acceleration += force;

	// new position
	position = position + (velocity * t);

	// new velocity
	velocity = velocity + (acceleration * t);

	// damp velocity
	// velocity = velocity * (1.0);	// do not damp
	velocity = velocity * (0.98);	// damp

	// check for max, min speed errors
	if (maxspeed < minspeed) {
		maxspeed = minspeed;
	}

	// limit velocity to max and min (min takes priority over max)
	float speed = glm::length(velocity);
	if (speed > maxspeed && speed != 0) {
		velocity = glm::normalize(velocity) * maxspeed;
	}
	if (speed < minspeed && speed != 0) {
		velocity = glm::normalize(velocity) * minspeed;
	}

	// reset acceleration
	acceleration = acceleration * 0.5;
	force = glm::vec3(0, 0, 0);

	// Wraparound checking
	//if (position.x < 0) position.x = ofGetWidth();
	//if (position.y < 0) position.y = ofGetHeight();
	//if (position.x > ofGetWidth()) position.x = 0;
	//if (position.y > ofGetHeight()) position.y = 0;

	// Debug Prints
	//cout << "P" << position << endl;
	//cout << "A" << acceleration << endl;
	//cout << "V" << velocity << endl;

	return;
}

void Boid::followTarget(glm::vec3 t) {
	// test print target location
	// cout << "t: " << t << endl;

	// get vectors
	glm::vec3 heading_vec	= heading - position;
	glm::vec3 target_vec	= t - position;

	// normalize vectors
	heading_vec = glm::normalize(heading_vec);
	target_vec	= glm::normalize(target_vec);
	//cout << "heading: " << heading << "\ttarget: " <<  target_vec << endl;
	
	// update boid.target vec for display (debugging feature)
	target = t;
	
	// create quat that rotates to target
	ofQuaternion q2;
	q2.ofQuaternion::makeRotate(heading_vec, target_vec);
	q2.normalize();

	// linearly interpolate between currunt rotation quat and target quat
	rotations.slerp(turning_rate, rotations, q2);

	// move forward
	accelerate();

	return;
}

void Boid::follow_robot(glm::vec3 robot_pos) {
	// test print target location
	// cout << robot_pos << endl;
	// cout << "t: " << t << endl;

	// get vectors
	glm::vec3 heading_vec	= heading - position;
	glm::vec3 target_vec	= robot_pos - position;

	// normalize vectors
	heading_vec = glm::normalize(heading_vec);
	target_vec = glm::normalize(target_vec);
	//cout << "heading: " << heading << "\ttarget: " <<  target_vec << endl;

	// update boid.target vec for display (debugging feature)
	target = target_vec;

	// create quat that rotates to target
	ofQuaternion q2;
	q2.ofQuaternion::makeRotate(heading_vec, target_vec);
	q2.normalize();

	// linearly interpolate between currunt rotation quat and target quat
	rotations.slerp(turning_rate, rotations, q2);

	// move forward
	accelerate();

	return;
}

void Boid::escape_robot(glm::vec3 robot_pos) {
	glm::vec3 steer = glm::vec3(0, 0, 0);

	// get distances
	float desired_seperation = 100.0f;
	float distance = glm::distance(position, robot_pos);

	// apply seperation rule
	if (distance > 0 && distance < desired_seperation) {
		predator_near = true;		// set bool to true, to avoid flocking rules while predator near
		glm::vec3 d_vec = position - robot_pos;
		d_vec = glm::normalize(d_vec);
		d_vec = d_vec / distance;	// weight by closeness
		steer += d_vec;
	}
	else {
		predator_near = false;		// predator not near, continue flocking
	}

	//cout << steer << endl;
	glm::vec3 heading_vec = heading - position;
	heading_vec = glm::normalize(heading_vec);

	ofQuaternion q2;
	q2.ofQuaternion::makeRotate(heading_vec, steer);
	q2.normalize();

	// linearly interpolate between current rotation quat and target quat
	rotations.slerp(turning_rate, rotations, q2);

	return;
}


// check if boid hits obstacle
bool Boid::hit_obstacle(Box b) {
	Vector3 p = Vector3(position.x, position.y, position.z);
	Vector3 h = Vector3(heading.x, heading.y, heading.z);

	Ray heading_ray = Ray(p, h);

	// check if ray hits
	bool hit = b.intersect(heading_ray, 0, 9999);

	return hit;
}


// avoid obstacles (boxes)
void Boid::obstacle_avoidance(Box b) {
	// get vectors
	glm::vec3 heading_vec = heading - position;
	glm::vec3 target_vec = glm::vec3(0,0,0) - position;

	// normalize vectors
	heading_vec = glm::normalize(heading_vec);
	target_vec = glm::normalize(target_vec);
	//cout << "heading: " << heading << "\ttarget: " <<  target_vec << endl;

	// update boid.target vec for display (debugging feature)
	target = glm::vec3(0,0,0);

	// create quat that rotates to target
	ofQuaternion q2;
	q2.ofQuaternion::makeRotate(heading_vec, target_vec);
	q2.normalize();

	// linearly interpolate between currunt rotation quat and target quat
	rotations.slerp(turning_rate, rotations, q2);

	// move forward
	accelerate();


	return;
}

void Boid::participate_in_flock(vector<Boid> boid_list) {

	// get seperation, cohesion, and alignment forces
	//cout << predator_near << endl;
	if (!predator_near) {	// flocking rules apply while predator is not near
		ofQuaternion sep = seperation(boid_list);
		ofQuaternion coh = cohesion(boid_list);
		ofQuaternion ali = alignment(boid_list);
	}
	
	accelerate();

	return;
}

ofQuaternion Boid::seperation(vector<Boid> boid_list) {
	glm::vec3 steer = glm::vec3(0, 0, 0);

	// loop through all boids
	for (int i = 0; i < boid_list.size(); i++) {
		Boid current_boid = boid_list[i];

		// ignore self in list
		if (this->position == current_boid.position) {
			continue;
		}

		// get distances
		float desired_seperation = 50.0f;
		float distance = glm::distance(this->position, current_boid.position);

		// apply seperation rule
		if (distance > 0 && distance < desired_seperation) {
			glm::vec3 d_vec = this->position - current_boid.position;
			d_vec = glm::normalize(d_vec);
			d_vec = d_vec / distance;	// weight by closeness
			steer += d_vec;
		}
	}

	//cout << steer << endl;
	glm::vec3 heading_vec = heading - position;
	heading_vec = glm::normalize(heading_vec);

	ofQuaternion q2;
	q2.ofQuaternion::makeRotate(heading_vec, steer);
	q2.normalize();

	// linearly interpolate between current rotation quat and target quat
	rotations.slerp(turning_rate, rotations, q2);

	return q2;
}

ofQuaternion Boid::cohesion(vector<Boid> boid_list) {
	glm::vec3 steer = glm::vec3(0, 0, 0);
	glm::vec3 neighborhood_centroid = glm::vec3(0, 0, 0);
	int count = 0;

	// loop through all boids
	for (int i = 0; i < boid_list.size(); i++) {
		Boid current_boid = boid_list[i];

		// ignore self in list
		if (this->position == current_boid.position) {
			continue;
		}

		// get distances
		float neighborhood = 300.0f;
		float distance = glm::distance(this->position, current_boid.position);

		//cout << distance << endl;

		// get neighborhood centroid posiition
		if (distance > 0 && distance < neighborhood) {
			neighborhood_centroid += current_boid.position;
			count += 1;
		}
	}

	//cout << "my_pos: " << this->position << "\tcentroid: " << neighborhood_centroid << endl;
	//cout << count << endl;

	// apply cohesion rule
	if (count > 0) {		// avoid divide by zero error
		neighborhood_centroid = neighborhood_centroid / count;	// get avg position
		steer = neighborhood_centroid;
		steer = glm::normalize(steer);
	}

	target = steer;
	//cout << steer << endl;

	ofQuaternion q2;
	q2.ofQuaternion::makeRotate(position, steer);
	q2.normalize();

	// linearly interpolate between current rotation quat and target quat
	rotations.slerp(turning_rate, rotations, q2);

	return q2;
}

ofQuaternion Boid::alignment(vector<Boid> boid_list) {
	glm::vec3 steer = glm::vec3(0, 0, 0);
	glm::vec3 neighborhood_heading = glm::vec3(0, 0, 0);
	int count = 0;

	// loop through all boids
	for (int i = 0; i < boid_list.size(); i++) {
		Boid current_boid = boid_list[i];

		// ignore self in list
		if (this->position == current_boid.position) {
			continue;
		}

		// get distances
		float neighborhood = 100.0f;
		float distance = glm::distance(this->position, current_boid.position);

		// get heading
		if (distance > 0 && distance < neighborhood) {
			neighborhood_heading += current_boid.velocity;
			count += 1;
		}
	}

	// apply alignment rule
	if (count > 0) {		// avoid divide by zero error
		neighborhood_heading = neighborhood_heading / count;		// get avg heading
		steer += neighborhood_heading;
	}

	glm::vec3 heading_vec = heading - position;
	heading_vec = glm::normalize(heading_vec);

	ofQuaternion q2;
	q2.ofQuaternion::makeRotate(heading_vec, steer);
	q2.normalize();

	// linearly interpolate between current rotation quat and target quat
	rotations.slerp(turning_rate, rotations, q2);

	return q2;
}

void Boid::accelerate() {
	glm::vec3 heading_vec = heading - position;
	heading_vec = glm::normalize(heading_vec);

	force += heading_vec * 150;
	return;
}

void Boid::decelerate() {
	glm::vec3 heading_vec = heading - position;
	heading_vec = glm::normalize(heading_vec);

	force -= heading_vec * 150;
	return;
}

void Boid::applyForce(glm::vec3 push) {
	force += push;
	return;
}