#include "ofApp.h"

// Helper Functions
float RandomFloat(float a, float b) {
	float random = ((float)rand()) / (float)RAND_MAX;
	float diff = b - a;
	float r = random * diff;
	return a + r;
}


//--------------------------------------------------------------
void ofApp::setup(){
	// GUI Setup
	gui.setup();	// most of the time you don't need a name
	gui2.setup();	// most of the time you don't need a name

	// BOID GUI
	gui.add(boid_num.setup("Number of Boids Displayed", 100, 1, 100));
	gui.add(boid_scale.setup("Boid Scale", 3, 1, 20));

	// BOID Physics
	gui.add(boid_minspeed.setup("Boid Min Speed", 10, 0, 300));
	gui.add(boid_maxspeed.setup("Boid Max Speed", 20, 0, 300));
	gui.add(boid_turning.setup("Boid Turning Rate", 0.1, 0, 1));
	gui.add(turbulence_pos.setup("Positive Turbulence", { 0, 0, 0 }, { 0, 0, 0 }, { 20, 20, 20 }));
	gui.add(turbulence_neg.setup("Negative Turbulence", { 0, 0, 0 }, { -20, -20, -20 }, { 0, 0, 0 }));

	// rotation testing slider
	gui.add(change_rotation.setup("Manually Change Rotation", false));
	gui.add(rotation_slide.setup("Rotation Testing", { 0, 0, 0 }, { 0, 0, 0 }, { 360, 360, 360 }));

	// flap frequency
	gui.add(flap_freq_slider.setup("Flap Frequency", 3, 1, 10));

	// robot thrust
	gui2.add(robot_thrust.setup("Robot Thrust", 150, 100, 300));
	gui2.add(predator_mode.setup("Robot Predator Mode", false));
	gui2.add(follower_mode.setup("Robot Follower Mode", false));

	// Mode GUI
	gui.add(targetting_mode.setup("Targetting Mode", false));
	gui.add(run_sim.setup("Run Simulation", false));
	gui.add(reset_button.setup("Reset Boids"));

	// Misc GUI
	gui.add(screenSize.setup("screen size", ofToString(ofGetWidth()) + "x" + ofToString(ofGetHeight())));

	// background
	// ofSetBackgroundColor(ofColor::black);

	// cam settings
	//cam.setDistance(10);
	//cam.setNearClip(.1);
	//ofEnableDepthTest();

	// enable or disable wireframe for models
	bWireFrame = false;

	// boid model 1
	if (!boidModel1.loadModel("bee1.obj")) {
		cout << "Can't load model 1" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded1 = true;
		boidModel1.setScaleNormalization(false);
	}

	// boid model 2
	if (!boidModel2.loadModel("bee2.obj")) {
		cout << "Can't load model 2" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded2 = true;
		boidModel2.setScaleNormalization(false);
	}

	// boid model 3
	if (!boidModel3.loadModel("bee3.obj")) {
		cout << "Can't load model 3 " << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded3 = true;
		boidModel3.setScaleNormalization(false);
	}

	// boid model 4
	if (!boidModel4.loadModel("bee4.obj")) {
		cout << "Can't load model 4" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded4 = true;
		boidModel4.setScaleNormalization(false);
	}

	// boid model 5
	if (!boidModel5.loadModel("bee5.obj")) {
		cout << "Can't load model 5" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded5 = true;
		boidModel5.setScaleNormalization(false);
	}

	// boid model 6
	if (!boidModel6.loadModel("bee6.obj")) {
		cout << "Can't load model 6" << endl;
		ofExit();
	}
	else {
		bBoidModelLoaded6 = true;
		boidModel6.setScaleNormalization(false);
	}

	// robot model
	if (!roboModel.loadModel("helo.obj")) {
		cout << "Can't load robot model" << endl;
		ofExit();
	}
	else {
		roboModelLoaded = true;
		roboModel.setScaleNormalization(false);
	}

	// print models
	cout << "Mesh 1 vertices: " << boidModel1.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 2 vertices: " << boidModel2.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 3 vertices: " << boidModel3.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 4 vertices: " << boidModel4.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 5 vertices: " << boidModel5.getMesh(0).getNumVertices() << endl;
	cout << "Mesh 6 vertices: " << boidModel6.getMesh(0).getNumVertices() << endl;
	cout << "Robot Mesh vertices: " << roboModel.getMesh(0).getNumVertices() << endl;

	// Set up lighting
	ofSetSmoothLighting(true);

	// setup one point light
	light1.enable();
	light1.setPosition(0, 20, 0);
	light1.setDiffuseColor(ofColor(255.f, 255.f, 255.f));
	light1.setSpecularColor(ofColor(255.f, 255.f, 255.f));
	light1.setAmbientColor(ofColor(150, 150, 150));

	// spawn robot
	Robot *r = new Robot;
	r->position = glm::vec3(0, 0, 0);

	int s = (int) boid_scale;
	r->scale	= glm::vec3(s, s, s);
	r->model	= &roboModel;
	r->thrust	= robot_thrust;
	r1 = *r;

	// create box
	Box* b = new Box(Vector3(-500, 0, -125), Vector3(-250, 1000, 125));
	Vector3 test = Vector3(10, 10, 10);
	b1 = *b;
}

//--------------------------------------------------------------
void ofApp::update(){
	// update scale
	float s = boid_scale;

	// update boids
	int current_boid_num = min(int(f1.boid_list.size()), int(boid_num));
	for (int i = 0; i < current_boid_num; i++) {
		// update scale
		f1.boid_list[i].scale = glm::vec3(s, s, s);

		// update min max speeds
		f1.boid_list[i].maxspeed = boid_maxspeed;
		f1.boid_list[i].minspeed = boid_minspeed;

		// update rotation when not in simulation
		if (change_rotation) {
			glm::vec3 euler_rot = glm::vec3(glm::radians(rotation_slide->x), glm::radians(rotation_slide->y), glm::radians(rotation_slide->z));
			glm::quat q = glm::quat(euler_rot);
			f1.boid_list[i].rotations = ofQuaternion(q);
		}

		// update turning rate
		f1.boid_list[i].turning_rate = boid_turning;

		// update flap freq
		f1.boid_list[i].flap_freq = flap_freq_slider;

		// update turbulence
		glm::vec3 t_pos = turbulence_pos;
		glm::vec3 t_neg = turbulence_neg;
		if (glm::length(t_pos) > 0 || glm::length(t_neg) > 0) {	// there is turbulence in at least one direction
			float t_x = RandomFloat(turbulence_pos->x, turbulence_neg->x);
			float t_y = RandomFloat(turbulence_pos->y, turbulence_neg->y);
			float t_z = RandomFloat(turbulence_pos->z, turbulence_neg->z);
			f1.boid_list[i].applyForce(glm::vec3(t_x, t_y, t_z));
		}

		// run simulations
		if (run_sim) {
			f1.boid_list[i].integrate();	// run physics
			bool o_in_way = f1.boid_list[i].hit_obstacle(b1); // check if boid hits obstacle

			if (o_in_way) {
				f1.boid_list[i].obstacle_avoidance(b1);		// make sure boid doesnt hit box
			}
			else if (predator_mode) {		// run predator mode
				f1.boid_list[i].escape_robot(r1.position);
			}
			else if (follower_mode) {		// run follower mode
				f1.boid_list[i].follow_robot(r1.position);
			}

			if (targetting_mode) {			// targetting mode enabled
				f1.boid_list[i].followTarget(target_circle_pos);
			}
			else {							// flock
				f1.boid_list[i].participate_in_flock(f1.boid_list);
			}
			
		}
	}

	// update robot
	r1.scale	= glm::vec3(s, s, s);
	r1.thrust	= robot_thrust;

	// run sim
	r1.integrate();

	if (reset_button) {
		f1.boid_list.clear();
		r1.position = glm::vec3(0, 0, 0);
		r1.rotations = ofQuaternion(-0.707107, 0, 0, 0.707107);	// set to default pos
	}
}

//--------------------------------------------------------------
void ofApp::draw(){

	// background
	ofBackgroundGradient(ofColor::white, ofColor::gray);

	// draw everything in 3D through camera
	cam.begin();

		// draw Grid
		ofPushMatrix();
		ofSetColor(ofColor::dimGray);
		ofRotateDeg(90);
		ofDrawGridPlane(15, 10);
		ofPopMatrix();

		// lighting
		ofEnableLighting();
		ofDisableLighting();

		// get box dimensions
		Vector3 box_center		= b1.center();
		glm::vec3 box_center2	= glm::vec3(box_center[0], box_center[1], box_center[2]);
		Vector3 box_max			= b1.max();
		Vector3 box_min			= b1.min();
		float width				= box_max[0] - box_min[0];
		float height			= box_max[1] - box_min[1];
		float depth				= box_max[2] - box_min[2];

		// draw box
		ofFill();
		ofSetColor(ofColor::blue);
		ofDrawBox(box_center2, width, height, depth);

		// draw targetting circle
		if (targetting_mode) {	// only draw in targetting mode
			ofFill();
			ofSetColor(ofColor::red);
			ofDrawSphere(target_circle_pos, 4);
		}

		// draw boids
		int current_boid_num = min(int(f1.boid_list.size()), int(boid_num));
		for (int i = 0; i < current_boid_num; i++) {
			f1.boid_list[i].draw();
		}

		// draw robot
		r1.draw();

	cam.end();

	// draw GUIs
	gui.draw();
	gui2.draw();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	int current_boid_num = min(int(f1.boid_list.size()), int(boid_num));
	if (key == OF_KEY_CONTROL) {	// enable placing boids
		place_boids = true;
	}
	else if (key == OF_KEY_UP) {	// move robot forwards
		r1.accelerate();
	}
	else if (key == OF_KEY_DOWN) {	// move robot backwards
		r1.decelerate();
	}
	else if (key == 'w') {			// move robot up
		r1.up();
	}
	else if (key == 's') {			// move robot down
		r1.down();
	}
	else if (key == 'a') {			// turn robot left
		r1.left();
	}
	else if (key == 'd') {			// turn robot right
		r1.right();
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
	if (key == OF_KEY_CONTROL) {	// disable placing boids
		place_boids = false;
	}

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
	//
	// construct mouse ray
	//
	glm::vec3 mouseWorld	= cam.screenToWorld(glm::vec3(x, y, 0));
	glm::vec3 camPosition	= cam.getPosition();
	glm::vec3 mouseDir		= glm::normalize(mouseWorld - camPosition);

	// test rayPlaneIntersect
	float dist;
	bool bIntersect = glm::intersectRayPlane(camPosition, mouseDir, glm::vec3(0, 0, 0), glm::vec3(0, 1, 0), dist);

	//cout << "intersect: " << bIntersect << endl;
	if (bIntersect) {
		//cout << "distance: " << dist << endl;

		// compute intersection point
		// r(t) = o + dt
		glm::vec3 p = camPosition + mouseDir * dist;

		//cout << "intersection point: " << p << endl;

		if (targetting_mode) {		// targetting mode on, turn boids towards point
			target_circle_pos = p;		// update targetting circle location
		}
		else if (place_boids) {		// placing boids is enabled
			// get current scale
			float s = boid_scale;

			// create new boid with current parameters
			Boid* bd = new Boid;
			bd->position	= p;
			bd->scale		= glm::vec3(s, s, s);
			//bd->rotation_xy	= 0;

			bd->flap_freq		= flap_freq_slider;
			bd->total_frames	= 0;
			//bd->start_frame		= 0;				// test case (dont draw model)
			bd->start_frame		= (rand() % 5) + 1;	// pick random start frame 1-6 
			bd->flap_direction  = true;

			bd->maxspeed		= boid_maxspeed;
			bd->minspeed		= boid_minspeed;
			bd->turning_rate	= boid_turning;

			bd->model1 = &boidModel1;
			bd->model2 = &boidModel2;
			bd->model3 = &boidModel3;
			bd->model4 = &boidModel4;
			bd->model5 = &boidModel5;
			bd->model6 = &boidModel6;

			bd->material = &beeMaterial;
			f1.addBoid(*bd);

			// accelerate the boid that was just added
			int i = f1.boid_list.size() - 1;
			f1.boid_list[i].accelerate();
			f1.boid_list[i].integrate();
		}
	}
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
